<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Apoteker extends CI_Controller
{
    function __construct()
    {
        parent::__construct();
        $this->load->model('Mlogin');
        $this->load->model('Mapoteker');
        $this->load->model('Mid');
    }
    public function obat()
    {
        $data['user'] = $this->Mlogin->get_all_user('apoteker')->row_object();
        $data['obat'] = $this->Mapoteker->getAllObat()->result();
        $this->template->load('layout/layout_apoteker', 'apoteker/data_obat', $data);
    }
    public function obat_masuk()
    {
        $data['user'] = $this->Mlogin->get_all_user('apoteker')->row_object();
        $data['obat'] = $this->Mapoteker->get_obatMasuk_by_apo()->result();
        $this->template->load('layout/layout_apoteker', 'apoteker/obat_masuk', $data);
    }
    public function aktif($id)
    {
        $dataUpdate = array('aktif' => '1');
        $this->Mapoteker->update('apoteker', $dataUpdate, 'id_apo', $id);
        redirect('Admin/apoteker');
    }

    public function non_aktif($id)
    {
        $dataUpdate = array('aktif' => '0');
        $this->Mapoteker->update('apoteker', $dataUpdate, 'id_apo', $id);
        redirect('Admin/apoteker');
    }
    public function add_apo()
    {

        $data['user'] = $this->Mlogin->get_all_user('admin')->row_object();
        $this->template->load('layout/layout_admin', 'apoteker/add_apoteker', $data);
    }
    public function aksi_simpan()
    {
        $nama = $this->input->post('nama');
        $username = $this->input->post('username');
        $password = $this->input->post('password');

        $dataInsert = array(
            'nama' => $nama,
            'username' => $username,
            'password' => $password
        );

        $this->Mapoteker->insert('apoteker', $dataInsert);
        redirect('Admin/apoteker');
    }
    public function edit_apo($id)
    {
        $datawhere = array('id_apo' => $id);
        $data['apoteker'] = $this->Mapoteker->get_by_id('apoteker', $datawhere)->row_object();
        $data['user'] = $this->Mlogin->get_all_user('admin')->row_object();
        $this->template->load('layout/layout_admin', 'apoteker/edit_apoteker', $data);
    }
    public function aksi_update()
    {
        $id_apo = $this->input->post('id');
        $nama = $this->input->post('nama');
        $username = $this->input->post('username');

        $dataUpdate = array(
            'nama' => $nama,
            'username' => $username
        );

        $this->Mapoteker->update('apoteker', $dataUpdate, 'id_apo', $id_apo);
        redirect('Admin/apoteker');
    }
    public function delete($id)
    {
        $this->db->where('id_apo', $id);
        if ($this->db->delete('apoteker')) {
            redirect('Admin/apoteker');
        } else {
            echo '<script>alert("Gagal menghapus data (Data Terpakai)."); document.location="../../Admin/apoteker";</script>';
        }
    }
}
