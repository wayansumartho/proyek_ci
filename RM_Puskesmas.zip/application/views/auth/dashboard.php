<!-- page content -->
<div class="right_col" role="main">
    <div class="">


        <div class="clearfix"></div>

        <div class="row">

            <div class="col-12">
                <div class="x_panel">

                    <div class="x_content">
                        <h1>
                            <p style="text-align: center;">
                                <br>
                                <img src="<?php echo base_url('assets/images/logo.png'); ?>" width="200px height=" 200px" /> <br><br>
                                Sistem Informasi Puskesmas<br>
                                Kecamatan Balinggi<br><br>
                        </h1>

                    </div>
                </div>
            </div>

        </div>
    </div>
</div>
<!-- /page content -->